export const banner = `TOOL SHARED BY FORESTARMY (https://t.me/forestarmy)`;
